function changePic(myStr) {
    var myElement= document.querySelector("#succulents");
    myElement.src = myStr
    console.log(myStr, myElement)  
}
function changePic(myStr) {
    var myElement= document.querySelector("#succulents");
    myElement.src = myStr
    console.log(myStr, myElement)  
}
function close(myStr) {
    var myElement= document.querySelector("sticky");
    myElement.classList.accept = myStr
    console.log(myStr, myElement)  
}
